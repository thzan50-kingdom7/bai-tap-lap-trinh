package com.example.uthlibrary

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument

// OOP: abstraction. Common behavior for users.
abstract class NguoiDung(
    private val ma: String,
    private var hoTen: String
) {
    fun layMa(): String = ma
    fun layHoTen(): String = hoTen
    fun doiHoTen(tenMoi: String) {
        if (tenMoi.isNotBlank()) hoTen = tenMoi
    }
    abstract fun thongTin(): String
}

// OOP: inheritance + polymorphism (override thongTin).
open class SinhVien(
    ma: String,
    hoTen: String,
    private val lop: String
) : NguoiDung(ma, hoTen) {
    fun layLop(): String = lop
    override fun thongTin(): String = "${layHoTen()} - ${layMa()} - Lớp $lop"
}

class SinhVienUuTu(
    ma: String,
    hoTen: String,
    lop: String,
    private val diemThuong: Int
) : SinhVien(ma, hoTen, lop) {
    override fun thongTin(): String = super.thongTin() + " - Điểm thưởng: $diemThuong"
}

// OOP: encapsulation. Data is private and changed through methods.
class Sach(
    private val ma: String,
    private var ten: String,
    private var tacGia: String
) {
    private var daMuon: Boolean = false
    fun layMa() = ma
    fun layTen() = ten
    fun layTacGia() = tacGia
    fun doiTen(tenMoi: String) { if (tenMoi.isNotBlank()) ten = tenMoi }
    fun trangThai() = if (daMuon) "Đang được mượn" else "Có sẵn"
    fun muon(): Boolean {
        if (daMuon) return false
        daMuon = true
        return true
    }
    fun tra() { daMuon = false }
}

class ThuVien {
    private val sachList = mutableStateListOf(
        Sach("S01", "Lập trình Kotlin", "Nguyễn Văn A"),
        Sach("S02", "Cơ sở dữ liệu", "Trần Thị B")
    )
    private val sinhVienList = mutableStateListOf<SinhVien>(
        SinhVien("SV01", "Nguyễn Văn A", "KTPM"),
        SinhVienUuTu("SV02", "Trần Thị B", "CNTT", 10)
    )
    fun sach() = sachList
    fun sinhVien() = sinhVienList
    fun themSach(ten: String, tacGia: String) {
        if (ten.isNotBlank()) {
            sachList.add(Sach("S%02d".format(sachList.size + 1), ten, tacGia.ifBlank { "Chưa rõ" }))
        }
    }
    fun themSinhVien(ten: String, lop: String) {
        if (ten.isNotBlank()) {
            sinhVienList.add(SinhVien("SV%02d".format(sinhVienList.size + 1), ten, lop.ifBlank { "Chưa rõ" }))
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val thuVien = ThuVien()
        setContent {
            MaterialTheme {
                LibraryApp(thuVien)
            }
        }
    }
}

@Composable
fun LibraryApp(thuVien: ThuVien) {
    val nav = rememberNavController()
    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = nav.currentDestination?.route == "home",
                    onClick = { nav.navigate("home") { launchSingleTop = true } },
                    icon = { Icon(Icons.Default.Home, null) },
                    label = { Text("Quản lý") }
                )
                NavigationBarItem(
                    selected = nav.currentDestination?.route == "books",
                    onClick = { nav.navigate("books") { launchSingleTop = true } },
                    icon = { Icon(Icons.Default.Book, null) },
                    label = { Text("DS Sách") }
                )
                NavigationBarItem(
                    selected = nav.currentDestination?.route == "students",
                    onClick = { nav.navigate("students") { launchSingleTop = true } },
                    icon = { Icon(Icons.Default.Person, null) },
                    label = { Text("Sinh viên") }
                )
            }
        }
    ) { padding ->
        NavHost(navController = nav, startDestination = "home", modifier = Modifier.padding(padding)) {
            composable("home") { HomeScreen(thuVien, onBooks = { nav.navigate("books") }, onStudents = { nav.navigate("students") }) }
            composable("books") { BooksScreen(thuVien) }
            composable("students") { StudentsScreen(thuVien) }
        }
    }
}

@Composable
fun HomeScreen(thuVien: ThuVien, onBooks: () -> Unit, onStudents: () -> Unit) {
    var tenSV by remember { mutableStateOf("Nguyễn Văn A") }
    var showNameDialog by remember { mutableStateOf(false) }
    var showBookDialog by remember { mutableStateOf(false) }
    var tenSach by remember { mutableStateOf("") }
    var tacGia by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Hệ thống Quản lý Thư viện", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Sinh viên", style = MaterialTheme.typography.titleMedium)
                Text(tenSV)
            }
            Button(onClick = { showNameDialog = true }) { Text("Thay đổi") }
        }
        Spacer(Modifier.height(20.dp))
        Text("Danh sách sách", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Card(Modifier.fillMaxWidth().heightIn(min = 130.dp)) {
            Column(Modifier.padding(12.dp)) {
                thuVien.sach().take(4).forEach { sach ->
                    Text("☑  ${sach.layTen()} — ${sach.trangThai()}", modifier = Modifier.padding(6.dp))
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick = { showBookDialog = true }) { Text("Thêm sách") }
        OutlinedButton(onClick = onBooks, modifier = Modifier.fillMaxWidth()) { Text("Xem danh sách sách") }
        OutlinedButton(onClick = onStudents, modifier = Modifier.fillMaxWidth()) { Text("Xem sinh viên") }
    }

    if (showNameDialog) {
        var tenMoi by remember { mutableStateOf(tenSV) }
        AlertDialog(
            onDismissRequest = { showNameDialog = false },
            title = { Text("Thay đổi sinh viên") },
            text = { OutlinedTextField(tenMoi, { tenMoi = it }, label = { Text("Họ tên") }) },
            confirmButton = {
                TextButton(onClick = { if (tenMoi.isNotBlank()) tenSV = tenMoi; showNameDialog = false }) { Text("Lưu") }
            },
            dismissButton = { TextButton(onClick = { showNameDialog = false }) { Text("Hủy") }
            }
        )
    }
    if (showBookDialog) {
        AlertDialog(
            onDismissRequest = { showBookDialog = false },
            title = { Text("Thêm sách") },
            text = {
                Column {
                    OutlinedTextField(tenSach, { tenSach = it }, label = { Text("Tên sách") })
                    OutlinedTextField(tacGia, { tacGia = it }, label = { Text("Tác giả") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    thuVien.themSach(tenSach, tacGia)
                    tenSach = ""; tacGia = ""; showBookDialog = false
                }) { Text("Thêm") }
            },
            dismissButton = { TextButton(onClick = { showBookDialog = false }) { Text("Hủy") } }
        )
    }
}

@Composable
fun BooksScreen(thuVien: ThuVien) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Danh sách sách", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        LazyColumn {
            items(thuVien.sach()) { sach ->
                var showDetail by remember { mutableStateOf(false) }
                Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(sach.layTen(), style = MaterialTheme.typography.titleMedium)
                        Text("Mã: ${sach.layMa()} • Tác giả: ${sach.layTacGia()}")
                        Text("Trạng thái: ${sach.trangThai()}")
                        Row {
                            Button(onClick = { sach.muon() }, enabled = sach.trangThai() == "Có sẵn") { Text("Mượn") }
                            Spacer(Modifier.width(8.dp))
                            OutlinedButton(onClick = { sach.tra() }, enabled = sach.trangThai() != "Có sẵn") { Text("Trả") }
                            Spacer(Modifier.width(8.dp))
                            TextButton(onClick = { showDetail = true }) { Text("Chi tiết") }
                        }
                    }
                }
                if (showDetail) {
                    AlertDialog(
                        onDismissRequest = { showDetail = false },
                        title = { Text("Thông tin sách") },
                        text = { Text("Mã: ${sach.layMa()}\nTên: ${sach.layTen()}\nTác giả: ${sach.layTacGia()}\n${sach.trangThai()}") },
                        confirmButton = { TextButton(onClick = { showDetail = false }) { Text("Đóng") } }
                    )
                }
            }
        }
    }
}

@Composable
fun StudentsScreen(thuVien: ThuVien) {
    var ten by remember { mutableStateOf("") }
    var lop by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Danh sách sinh viên", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(ten, { ten = it }, label = { Text("Họ tên sinh viên") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(lop, { lop = it }, label = { Text("Lớp") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { thuVien.themSinhVien(ten, lop); ten = ""; lop = "" }, modifier = Modifier.padding(top = 8.dp)) {
            Text("Thêm sinh viên")
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn {
            items(thuVien.sinhVien()) { sv ->
                Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                    Text(sv.thongTin(), modifier = Modifier.padding(12.dp))
                }
            }
        }
    }
}
