package com.example.bai_bang_diem

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
