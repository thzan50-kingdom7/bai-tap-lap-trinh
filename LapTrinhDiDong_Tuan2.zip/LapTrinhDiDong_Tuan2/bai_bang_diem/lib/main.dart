
import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: ClassScorePage(),
  ));
}

class Student {
  String name;
  double? score;

  Student(this.name, this.score);
}

String classifyGrade(double score) {
  if (score < 0 || score > 10) {
    return 'Không hợp lệ';
  } else if (score >= 8) {
    return 'Giỏi';
  } else if (score >= 6.5) {
    return 'Khá';
  } else if (score >= 5) {
    return 'Trung bình';
  } else {
    return 'Yếu';
  }
}

class ClassScorePage extends StatelessWidget {
  const ClassScorePage({super.key});

  @override
  Widget build(BuildContext context) {
    List<Student> students = [
      Student('An', 9.0),
      Student('Binh', 7.2),
      Student('Chi', null),
      Student('Dung', 4.5),
      Student('Em', 5.8),
    ];

    double total = 0;
    int count = 0;
    int excellent = 0;
    int noScore = 0;
    double? highest;

    for (var student in students) {
      if (student.score == null) {
        noScore++;
      } else {
        double score = student.score!;
        total += score;
        count++;

        if (score >= 8) {
          excellent++;
        }

        if (highest == null || score > highest) {
          highest = score;
        }
      }
    }

    double average = count > 0 ? total / count : 0;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Bảng điểm sinh viên'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            color: Colors.blue.shade50,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                'Điểm trung bình: ${average.toStringAsFixed(2)}\n'
                'Số sinh viên Giỏi: $excellent\n'
                'Số sinh viên chưa có điểm: $noScore\n'
                'Điểm cao nhất: ${highest ?? "Chưa có"}',
                style: const TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          for (var student in students)
            Card(
              child: ListTile(
                leading: const Icon(Icons.school),
                title: Text(student.name),
                subtitle: Text(
                  student.score == null
                      ? 'Điểm: Chưa có điểm'
                      : 'Điểm: ${student.score} - '
                          '${classifyGrade(student.score!)}',
                ),
              ),
            ),
        ],
      ),
    );
  }
}
