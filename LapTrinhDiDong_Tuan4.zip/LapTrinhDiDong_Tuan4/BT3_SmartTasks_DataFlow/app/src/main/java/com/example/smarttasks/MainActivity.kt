package com.example.smarttasks

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import androidx.navigation.NavHostController
import android.net.Uri

// OOP model: encapsulated email and verification state.
class PasswordResetFlow(private val email: String) {
    private var verified: Boolean = false
    fun getEmail(): String = email
    fun verify(code: String): Boolean {
        // Demo-only OTP. Real apps must verify securely on a server.
        verified = code == "12345"
        return verified
    }
    fun isVerified(): Boolean = verified
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                SmartTasksApp()
            }
        }
    }
}

@Composable
fun SmartTasksApp() {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "forgot") {
        composable("forgot") {
            ForgotScreen(onNext = { email ->
                nav.navigate("verify/${Uri.encode(email)}")
            })
        }
        composable(
            "verify/{email}",
            arguments = listOf(navArgument("email") { type = NavType.StringType })
        ) { entry ->
            val email = Uri.decode(entry.arguments?.getString("email").orEmpty())
            VerifyScreen(email, onBack = { nav.popBackStack() }, onNext = { code ->
                nav.navigate("reset/${Uri.encode(email)}/${Uri.encode(code)}")
            })
        }
        composable(
            "reset/{email}/{code}",
            arguments = listOf(
                navArgument("email") { type = NavType.StringType },
                navArgument("code") { type = NavType.StringType }
            )
        ) { entry ->
            val email = Uri.decode(entry.arguments?.getString("email").orEmpty())
            val code = Uri.decode(entry.arguments?.getString("code").orEmpty())
            ResetScreen(email, code, onBack = { nav.popBackStack() }, onNext = {
                nav.navigate("confirm/${Uri.encode(email)}")
            })
        }
        composable(
            "confirm/{email}",
            arguments = listOf(navArgument("email") { type = NavType.StringType })
        ) { entry ->
            val email = Uri.decode(entry.arguments?.getString("email").orEmpty())
            ConfirmScreen(email, onBack = { nav.popBackStack() }, onFinish = {
                nav.popBackStack("forgot", inclusive = false)
            })
        }
    }
}

@Composable
fun ScreenFrame(title: String, onBack: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Quay lại") }
            }
            Text("UTH", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
        }
        Spacer(Modifier.height(8.dp))
        Text("SmartTasks", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(32.dp))
        Text(title, style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        content()
    }
}

@Composable
fun ForgotScreen(onNext: (String) -> Unit) {
    var email by remember { mutableStateOf("") }
    ScreenFrame("Forgot Password?") {
        Text("Nhập email để nhận mã xác minh.")
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            value = email, onValueChange = { email = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Your Email") },
            leadingIcon = { Icon(Icons.Default.Email, null) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            singleLine = true
        )
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { onNext(email.trim()) },
            enabled = email.contains("@") && email.contains("."),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp)
        ) { Text("Next") }
    }
}

@Composable
fun VerifyScreen(email: String, onBack: () -> Unit, onNext: (String) -> Unit) {
    var code by remember { mutableStateOf("") }
    ScreenFrame("Verify Code", onBack) {
        Text("Mã xác minh đã được gửi tới:")
        Text(email, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            value = code, onValueChange = { if (it.length <= 5) code = it },
            label = { Text("OTP (demo: 12345)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = { onNext(code) }, enabled = code.length == 5, modifier = Modifier.fillMaxWidth()) {
            Text("Next")
        }
    }
}

@Composable
fun ResetScreen(email: String, code: String, onBack: () -> Unit, onNext: () -> Unit) {
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    ScreenFrame("Create new password", onBack) {
        Text("Tài khoản: $email")
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = password, onValueChange = { password = it },
            label = { Text("Password") }, leadingIcon = { Icon(Icons.Default.Lock, null) },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(), singleLine = true
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = confirm, onValueChange = { confirm = it },
            label = { Text("Confirm Password") }, leadingIcon = { Icon(Icons.Default.Lock, null) },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(), singleLine = true
        )
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            error = when {
                code != "12345" -> "Mã OTP không đúng (bài demo dùng 12345)."
                password.length < 6 -> "Mật khẩu cần ít nhất 6 ký tự."
                password != confirm -> "Hai mật khẩu không khớp."
                else -> ""
            }
            if (error.isEmpty()) onNext()
        }, modifier = Modifier.fillMaxWidth()) { Text("Next") }
    }
}

@Composable
fun ConfirmScreen(email: String, onBack: () -> Unit, onFinish: () -> Unit) {
    ScreenFrame("Confirm", onBack) {
        Text("Đặt lại mật khẩu thành công!", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(value = email, onValueChange = {}, readOnly = true,
            label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Button(onClick = onFinish, modifier = Modifier.fillMaxWidth()) { Text("Submit") }
    }
}
