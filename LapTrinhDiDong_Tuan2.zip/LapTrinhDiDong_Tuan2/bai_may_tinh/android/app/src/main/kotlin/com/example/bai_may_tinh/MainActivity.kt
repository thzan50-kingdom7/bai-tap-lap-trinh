package com.example.bai_may_tinh

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
