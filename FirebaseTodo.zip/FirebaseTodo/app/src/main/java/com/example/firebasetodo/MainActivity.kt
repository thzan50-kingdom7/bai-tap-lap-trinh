
package com.example.firebasetodo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.firebasetodo.ui.theme.FirebaseTodoTheme
import com.google.firebase.auth.FirebaseAuth

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            FirebaseTodoTheme {
                AuthApp()
            }
        }
    }
}

@Composable
fun AuthApp() {
    val auth = remember { FirebaseAuth.getInstance() }

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isRegister by remember { mutableStateOf(false) }
    var isLoggedIn by remember {
        mutableStateOf(auth.currentUser != null)
    }
    var userEmail by remember {
        mutableStateOf(auth.currentUser?.email ?: "")
    }
    var message by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    if (isLoggedIn) {
        HomeScreen(
            email = userEmail,
            onLogout = {
                auth.signOut()
                isLoggedIn = false
                email = ""
                password = ""
                message = ""
            }
        )
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "UTH TODO",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (isRegister) "Tạo tài khoản mới"
                else "Chào mừng bạn trở lại!"
            )

            Spacer(modifier = Modifier.height(28.dp))

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Địa chỉ Email") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Mật khẩu") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = {
                    if (email.isBlank() || password.isBlank()) {
                        message = "Vui lòng nhập email và mật khẩu!"
                    } else if (password.length < 6) {
                        message = "Mật khẩu phải có ít nhất 6 ký tự!"
                    } else {
                        isLoading = true
                        message = ""

                        val task = if (isRegister) {
                            auth.createUserWithEmailAndPassword(
                                email.trim(),
                                password
                            )
                        } else {
                            auth.signInWithEmailAndPassword(
                                email.trim(),
                                password
                            )
                        }

                        task.addOnCompleteListener { result ->
                            isLoading = false

                            if (result.isSuccessful) {
                                userEmail = auth.currentUser?.email ?: email
                                isLoggedIn = true
                                message = ""
                            } else {
                                message = result.exception?.localizedMessage
                                    ?: "Đã xảy ra lỗi. Vui lòng thử lại."
                            }
                        }
                    }
                },
                enabled = !isLoading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                } else {
                    Text(
                        if (isRegister) "ĐĂNG KÝ" else "ĐĂNG NHẬP"
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            TextButton(
                onClick = {
                    isRegister = !isRegister
                    message = ""
                }
            ) {
                Text(
                    if (isRegister)
                        "Đã có tài khoản? Đăng nhập"
                    else
                        "Chưa có tài khoản? Đăng ký"
                )
            }

            if (message.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = message,
                    color = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}

@Composable
fun HomeScreen(
    email: String,
    onLogout: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "UTH TODO",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Đăng nhập thành công!",
            style = MaterialTheme.typography.titleLarge
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(text = "Tài khoản: $email")

        Spacer(modifier = Modifier.height(24.dp))

        Button(onClick = onLogout) {
            Text("ĐĂNG XUẤT")
        }
    }
}
