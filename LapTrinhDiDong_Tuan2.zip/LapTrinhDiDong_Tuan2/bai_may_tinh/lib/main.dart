
import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: CalculatorPage(),
  ));
}

class CalculatorPage extends StatefulWidget {
  const CalculatorPage({super.key});

  @override
  State<CalculatorPage> createState() => _CalculatorPageState();
}

class _CalculatorPageState extends State<CalculatorPage> {
  final TextEditingController firstController = TextEditingController();
  final TextEditingController secondController = TextEditingController();

  String result = 'Kết quả sẽ hiển thị ở đây';

  void calculate(String operation) {
    final first = double.tryParse(firstController.text);
    final second = double.tryParse(secondController.text);

    setState(() {
      if (first == null || second == null) {
        result = 'Vui lòng nhập hai số hợp lệ';
        return;
      }

      double value;

      switch (operation) {
        case '+':
          value = first + second;
          break;
        case '-':
          value = first - second;
          break;
        case '*':
          value = first * second;
          break;
        case '/':
          if (second == 0) {
            result = 'Không thể chia cho 0';
            return;
          }
          value = first / second;
          break;
        default:
          return;
      }

      result = 'Kết quả: $value';
    });
  }

  @override
  void dispose() {
    firstController.dispose();
    secondController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Máy tính đơn giản'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 450),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextField(
                  controller: firstController,
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                    signed: true,
                  ),
                  decoration: const InputDecoration(
                    labelText: 'Nhập số thứ nhất',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: secondController,
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                    signed: true,
                  ),
                  decoration: const InputDecoration(
                    labelText: 'Nhập số thứ hai',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 20),
                Wrap(
                  alignment: WrapAlignment.center,
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    ElevatedButton(
                      onPressed: () => calculate('+'),
                      child: const Text('Cộng (+)'),
                    ),
                    ElevatedButton(
                      onPressed: () => calculate('-'),
                      child: const Text('Trừ (-)'),
                    ),
                    ElevatedButton(
                      onPressed: () => calculate('*'),
                      child: const Text('Nhân (*)'),
                    ),
                    ElevatedButton(
                      onPressed: () => calculate('/'),
                      child: const Text('Chia (/)'),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                Text(
                  result,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
