
import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: StudentListPage(),
  ));
}

class Student {
  String name;
  String? email;
  String? phone;

  Student(this.name, this.email, this.phone);
}

class StudentListPage extends StatelessWidget {
  const StudentListPage({super.key});

  @override
  Widget build(BuildContext context) {
    List<Student> students = [
      Student('Nguyen Van An', 'an@gmail.com', '0901234567'),
      Student('Tran Thi Binh', null, '0912345678'),
      Student('Le Van Cuong', 'cuong@gmail.com', null),
      Student('Pham Thi Dung', null, null),
      Student('Hoang Van Em', 'em@gmail.com', '0987654321'),
    ];

    int missingEmail = 0;

    for (var student in students) {
      if (student.email == null) {
        missingEmail++;
      }
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Danh sách sinh viên'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            color: Colors.blue.shade50,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                'Tổng số sinh viên: ${students.length}\n'
                'Sinh viên thiếu email: $missingEmail',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          for (var student in students)
            Card(
              child: ListTile(
                leading: const CircleAvatar(
                  child: Icon(Icons.person),
                ),
                title: Text(student.name),
                subtitle: Text(
                  'Email: ${student.email ?? "Chưa cập nhật"}\n'
                  'Điện thoại: ${student.phone ?? "Chưa cập nhật"}',
                ),
                isThreeLine: true,
              ),
            ),
        ],
      ),
    );
  }
}
