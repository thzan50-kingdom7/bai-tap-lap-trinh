
package com.example.laptrinhdidong_tuan4

import android.app.DatePickerDialog
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar

private val Blue = Color(0xFFB9DDF5)
private val DarkBlue = Color(0xFF438BEA)
private val TitleBlue = Color(0xFF4198C5)
private val Red = Color(0xFFF4B1B1)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.White
                ) {
                    UIComponentsApp()
                }
            }
        }
    }
}

data class UIItem(
    val name: String,
    val description: String,
    val category: String
)

private val uiItems = listOf(
    UIItem("Text", "Displays text", "Display"),
    UIItem("Image", "Displays an image", "Display"),
    UIItem("TextField", "Input field for text", "Input"),
    UIItem("PasswordField", "Input field for passwords", "Input"),
    UIItem("Toggle", "On/off switch", "Input"),
    UIItem("Slider", "Selects a value from a range", "Input"),
    UIItem("DatePicker", "Selects a date", "Input"),
    UIItem("Button", "Triggers an action when tapped", "Selection"),
    UIItem("Checkbox", "Selects one or multiple options", "Selection"),
    UIItem("RadioButton", "Selects a single option", "Selection"),
    UIItem("Picker", "Selects a value from a list", "Selection"),
    UIItem("NavigationView", "Navigation with title and back button", "Navigation"),
    UIItem("TabBar", "Switches between main sections", "Navigation"),
    UIItem("Menu", "Shows a menu with multiple actions", "Navigation"),
    UIItem("List", "Displays a list of items", "Content"),
    UIItem("Card", "Container with content and style", "Content"),
    UIItem("Divider", "Separates content into sections", "Content"),
    UIItem("Row Layout", "Arranges elements horizontally", "Layout"),
    UIItem("Column", "Arranges elements vertically", "Layout")
)

@Composable
fun UIComponentsApp() {
    var screen by remember { mutableStateOf("Welcome") }
    var selectedItem by remember { mutableStateOf("Text") }

    when (screen) {
        "Welcome" -> WelcomeScreen {
            screen = "Components"
        }

        "Components" -> ComponentsScreen(
            onItemClick = {
                selectedItem = it
                screen = "Detail"
            }
        )

        "Detail" -> DetailScreen(
            itemName = selectedItem,
            onBack = { screen = "Components" }
        )
    }
}

@Composable
fun WelcomeScreen(onReady: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "I'm Ready",
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp),
            fontSize = 14.sp,
            color = Color.Gray
        )

        Spacer(Modifier.weight(1f))

        // Logo minh họa bằng hình khối, không cần file ảnh.
        Box(
            modifier = Modifier
                .size(112.dp)
                .background(
                    Color(0xFF168E70),
                    RoundedCornerShape(24.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .background(
                        DarkBlue,
                        RoundedCornerShape(18.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .background(
                            Color.White,
                            RoundedCornerShape(10.dp)
                        )
                )
            }
        }

        Spacer(Modifier.height(24.dp))

        Text(
            text = "Jetpack Compose",
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp
        )

        Spacer(Modifier.height(12.dp))

        Text(
            text = "Jetpack Compose is a modern UI toolkit " +
                    "for building native Android applications " +
                    "using a declarative programming approach.",
            fontSize = 13.sp,
            color = Color.Gray,
            lineHeight = 19.sp
        )

        Spacer(Modifier.weight(1f))

        Button(
            onClick = onReady,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(28.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF2697EA)
            )
        ) {
            Text("I'm ready")
        }
    }
}

@Composable
fun ComponentsScreen(onItemClick: (String) -> Unit) {
    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "UI Components List",
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            color = TitleBlue,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                bottom = 24.dp
            ),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val categories = listOf(
                "Display", "Input", "Selection",
                "Navigation", "Content", "Layout"
            )

            categories.forEach { category ->
                item(key = "header_$category") {
                    Text(
                        text = category,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        modifier = Modifier.padding(top = 8.dp, bottom = 2.dp)
                    )
                }

                uiItems.filter { it.category == category }.forEach { item ->
                    item(key = item.name) {
                        ComponentCard(item) {
                            onItemClick(item.name)
                        }
                    }
                }
            }

            item {
                Spacer(Modifier.height(8.dp))
                ComponentCard(
                    UIItem(
                        "Tự tìm hiểu",
                        "Tìm ra tất cả các thành phần UI cơ bản",
                        "Extra"
                    ),
                    background = Red
                ) {
                    onItemClick("Tự tìm hiểu")
                }
            }
        }
    }
}

@Composable
fun ComponentCard(
    item: UIItem,
    background: Color = Blue,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(background, RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(
            text = item.name,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
        )
        Text(
            text = item.description,
            fontSize = 13.sp,
            color = Color(0xFF333333)
        )
    }
}

@Composable
fun DetailScreen(itemName: String, onBack: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "‹",
                color = TitleBlue,
                fontSize = 32.sp,
                modifier = Modifier
                    .clickable { onBack() }
                    .padding(horizontal = 8.dp)
            )

            Text(
                text = if (itemName == "Text") "Text Detail" else itemName,
                modifier = Modifier.weight(1f),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                color = TitleBlue,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp
            )

            Spacer(Modifier.width(32.dp))
        }

        when (itemName) {
            "Text" -> TextDetail()
            "Image" -> ImageDetail()
            "TextField" -> TextFieldDetail()
            "PasswordField" -> PasswordDetail()
            "Toggle" -> ToggleDetail()
            "Slider" -> SliderDetail()
            "DatePicker" -> DatePickerDetail()
            "Button" -> ButtonDetail()
            "Checkbox" -> CheckboxDetail()
            "RadioButton" -> RadioDetail()
            "Picker" -> PickerDetail()
            "NavigationView" -> NavigationDetail()
            "TabBar" -> TabBarDetail()
            "Menu" -> MenuDetail()
            "List" -> ListDetail()
            "Card" -> CardDetail()
            "Divider" -> DividerDetail()
            "Row Layout" -> RowLayoutDetail()
            "Column" -> ColumnDetail()
            else -> LearnDetail()
        }
    }
}

@Composable
fun TextDetail() {
    val sample = buildAnnotatedString {
        append("The ")
        withStyle(SpanStyle(textDecoration = TextDecoration.LineThrough)) {
            append("quick ")
        }
        withStyle(SpanStyle(color = Color(0xFFB17A27), fontSize = 30.sp)) {
            append("Brown")
        }
        append("\nfox j u m p s ")
        withStyle(SpanStyle(fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic)) {
            append("over")
        }
        append("\n")
        withStyle(SpanStyle(textDecoration = TextDecoration.Underline)) {
            append("the ")
        }
        withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
            append("lazy")
        }
        append(" dog.")
    }

    Text(
        text = sample,
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 28.dp, end = 24.dp, top = 150.dp),
        fontSize = 24.sp,
        lineHeight = 42.sp
    )

    HorizontalDivider(
        modifier = Modifier.padding(horizontal = 24.dp, vertical = 20.dp),
        color = Color.LightGray
    )
}

@Composable
fun ImageDetail() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Hai ảnh minh họa tự tạo bằng các khối màu.
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(155.dp)
                .background(Color(0xFFD8EAF5), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "Ảnh trường đại học 1",
                color = Color(0xFF276A8C),
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(Modifier.height(8.dp))
        Text("Ảnh minh họa 1", fontSize = 12.sp)

        Spacer(Modifier.height(24.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(155.dp)
                .background(Color(0xFFBBD7C2), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "Ảnh trường đại học 2",
                color = Color(0xFF286648),
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(Modifier.height(8.dp))
        Text("Ảnh minh họa 2", fontSize = 12.sp)
    }
}

@Composable
fun TextFieldDetail() {
    var text by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Thông tin nhập") },
            singleLine = true
        )

        Spacer(Modifier.height(16.dp))

        Text(
            text = if (text.isEmpty())
                "Tự động cập nhật dữ liệu theo textfield"
            else
                "Bạn đã nhập: $text",
            fontSize = 13.sp,
            color = Color(0xFFAD6262)
        )
    }
}

@Composable
fun PasswordDetail() {
    var password by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Mật khẩu") },
            visualTransformation = if (showPassword)
                androidx.compose.ui.text.input.VisualTransformation.None
            else PasswordVisualTransformation(),
            singleLine = true
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(showPassword, { showPassword = it })
            Text("Hiện mật khẩu")
        }
    }
}

@Composable
fun ToggleDetail() {
    var enabled by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(if (enabled) "Đang bật" else "Đang tắt", fontSize = 20.sp)
        Spacer(Modifier.height(12.dp))
        Switch(checked = enabled, onCheckedChange = { enabled = it })
    }
}

@Composable
fun SliderDetail() {
    var value by remember { mutableFloatStateOf(50f) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Giá trị: ${value.toInt()}", fontSize = 20.sp)
        Slider(
            value = value,
            onValueChange = { value = it },
            valueRange = 0f..100f
        )
    }
}

@Composable
fun DatePickerDetail() {
    val context = LocalContext.current
    var date by remember { mutableStateOf("Chưa chọn ngày") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(date)
        Spacer(Modifier.height(12.dp))

        Button(onClick = {
            val calendar = Calendar.getInstance()
            DatePickerDialog(
                context,
                { _, year, month, day ->
                    date = "$day/${month + 1}/$year"
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            ).show()
        }) {
            Text("Chọn ngày")
        }
    }
}

@Composable
fun ButtonDetail() {
    var message by remember { mutableStateOf("Chưa nhấn nút") }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Button(onClick = { message = "Bạn đã nhấn Button!" }) {
            Text("Nhấn vào đây")
        }
        Spacer(Modifier.height(12.dp))
        Text(message)
    }
}

@Composable
fun CheckboxDetail() {
    var checked1 by remember { mutableStateOf(false) }
    var checked2 by remember { mutableStateOf(true) }

    Column(Modifier.padding(24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked1, { checked1 = it })
            Text("Lựa chọn 1")
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked2, { checked2 = it })
            Text("Lựa chọn 2")
        }
        Text("Đã chọn: ${(listOf(checked1, checked2).count { it })} mục")
    }
}

@Composable
fun RadioDetail() {
    var selected by remember { mutableStateOf("Android") }

    Column(Modifier.padding(24.dp)) {
        listOf("Android", "iOS", "Web").forEach { option ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = selected == option,
                    onClick = { selected = option }
                )
                Text(option)
            }
        }
        Text("Bạn chọn: $selected")
    }
}

@Composable
fun PickerDetail() {
    var expanded by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf("Chọn một mục") }
    val options = listOf("Mục 1", "Mục 2", "Mục 3")

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column {
            OutlinedButton(onClick = { expanded = true }) {
                Text(selected)
            }
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                options.forEach { option ->
                    DropdownMenuItem(
                        text = { Text(option) },
                        onClick = {
                            selected = option
                            expanded = false
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun NavigationDetail() {
    Column(Modifier.padding(24.dp)) {
        Text("NavigationView", fontSize = 22.sp, color = TitleBlue)
        Spacer(Modifier.height(12.dp))
        Text("Đây là màn hình chi tiết. Nhấn mũi tên quay lại ở phía trên để trở về danh sách.")
    }
}

@Composable
fun TabBarDetail() {
    var selected by remember { mutableIntStateOf(0) }
    val tabs = listOf("Trang chủ", "Yêu thích", "Cá nhân")

    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = selected) {
            tabs.forEachIndexed { index, tab ->
                Tab(
                    selected = selected == index,
                    onClick = { selected = index },
                    text = { Text(tab) }
                )
            }
        }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("Nội dung: ${tabs[selected]}")
        }
    }
}

@Composable
fun MenuDetail() {
    var expanded by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Chọn menu để xem các chức năng") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Button(onClick = { expanded = true }) {
                Text("Mở Menu")
            }
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                listOf("Trang chủ", "Cài đặt", "Trợ giúp").forEach { option ->
                    DropdownMenuItem(
                        text = { Text(option) },
                        onClick = {
                            message = "Bạn chọn: $option"
                            expanded = false
                        }
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(message)
        }
    }
}

@Composable
fun ListDetail() {
    Column(Modifier.padding(16.dp)) {
        listOf("Phần tử 1", "Phần tử 2", "Phần tử 3", "Phần tử 4")
            .forEach { value ->
                Text(value, modifier = Modifier.padding(12.dp))
                HorizontalDivider()
            }
    }
}

@Composable
fun CardDetail() {
    Column(Modifier.padding(24.dp)) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Blue)
        ) {
            Column(Modifier.padding(20.dp)) {
                Text("Thẻ thông tin", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Card dùng để nhóm nội dung trong giao diện.")
                Spacer(Modifier.height(12.dp))
                Button(onClick = {}) {
                    Text("Chi tiết")
                }
            }
        }
    }
}

@Composable
fun DividerDetail() {
    Column(Modifier.padding(24.dp)) {
        Text("Nội dung phía trên")
        HorizontalDivider(
            modifier = Modifier.padding(vertical = 20.dp),
            thickness = 1.dp
        )
        Text("Nội dung phía dưới")
    }
}

@Composable
fun RowLayoutDetail() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        repeat(4) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Color(0xFFF3F5F8),
                        RoundedCornerShape(12.dp)
                    )
                    .padding(6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                repeat(3) { index ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .background(
                                if (index == 1) DarkBlue
                                else Color(0xFFA9C5F2),
                                RoundedCornerShape(10.dp)
                            )
                    )
                }
            }
        }
    }
}

@Composable
fun ColumnDetail() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        repeat(4) { index ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(55.dp)
                    .background(
                        Blue,
                        RoundedCornerShape(10.dp)
                    ),
                contentAlignment = Alignment.CenterStart
            ) {
                Text("Phần tử ${index + 1}", modifier = Modifier.padding(12.dp))
            }
        }
    }
}

@Composable
fun LearnDetail() {
    Column(Modifier.padding(24.dp)) {
        Text(
            "Tìm hiểu thêm về các thành phần UI cơ bản.",
            fontSize = 18.sp
        )
        Spacer(Modifier.height(12.dp))
        Text("Text, Image, Input, Selection, Navigation, Content và Layout.")
    }
}
