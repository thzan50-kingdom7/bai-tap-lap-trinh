UTH - BỘ BÀI TẬP NAVIGATION + OOP + DATA FLOW
================================================

Có 2 project Android độc lập:

1. BT1_ThuVien_OOP_Navigation
   - Quản lý thư viện: màn hình Quản lý, DS Sách, Sinh viên.
   - Thêm sách, thêm sinh viên, mượn/trả sách, xem chi tiết.
   - OOP đủ 4 đặc trưng:
       * Đóng gói: thuộc tính private, truy cập qua hàm.
       * Kế thừa: SinhVienUuTu : SinhVien.
       * Đa hình: override thongTin().
       * Trừu tượng: abstract class NguoiDung.
   - Dữ liệu mẫu nằm trong code, chưa lưu bền sau khi tắt app.

2. BT3_SmartTasks_DataFlow
   - 4 màn hình: Forgot Password -> Verify Code -> Reset Password -> Confirm.
   - Email được truyền qua Navigation arguments.
   - OTP demo là 12345; không phải xác minh email thật.
   - Mật khẩu chỉ dùng trong màn hình reset và không truyền qua route.

CÁCH MỞ CHẠY:
1. Giải nén file ZIP.
2. Mở Android Studio.
3. Chọn File > Open.
4. Mở riêng thư mục BT1_ThuVien_OOP_Navigation.
5. Chờ Gradle Sync hoàn tất; chọn máy ảo Android rồi bấm Run (tam giác xanh).
6. Muốn chạy bài 03, mở project BT3_SmartTasks_DataFlow riêng.
7. Không mở thư mục ZIP cha như một project; hãy mở đúng thư mục có settings.gradle.kts.

YÊU CẦU MÔI TRƯỜNG:
- Android Studio có Android SDK.
- JDK 17.
- Kết nối Internet lần đầu để tải Gradle/dependencies.
- Nếu Android Studio báo thiếu SDK 35, cài Android SDK Platform 35 trong SDK Manager.

LƯU Ý:
- Mỗi project là độc lập, có thể nộp riêng hoặc đặt trong cùng repository GitHub.
- Đây là bản mẫu học tập, dùng dữ liệu trong bộ nhớ; chưa có database.
- SmartTasks sử dụng OTP demo 12345. Ứng dụng thực tế phải xác minh OTP qua máy chủ.
