
import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: GradePage(),
  ));
}

String classifyGrade(double score) {
  if (score < 0 || score > 10) {
    return 'Điểm không hợp lệ';
  } else if (score >= 8) {
    return 'Giỏi';
  } else if (score >= 6.5) {
    return 'Khá';
  } else if (score >= 5) {
    return 'Trung bình';
  } else {
    return 'Yếu';
  }
}

class GradePage extends StatefulWidget {
  const GradePage({super.key});

  @override
  State<GradePage> createState() => _GradePageState();
}

class _GradePageState extends State<GradePage> {
  final TextEditingController controller =
      TextEditingController(text: '8.5');

  String result = '';

  void checkGrade() {
    double? score = double.tryParse(
      controller.text.trim().replaceAll(',', '.'),
    );

    setState(() {
      if (score == null) {
        result = 'Vui lòng nhập điểm hợp lệ';
      } else {
        result = 'Điểm: $score\nXếp loại: ${classifyGrade(score)}';
      }
    });
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Xếp loại học lực'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: controller,
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              decoration: const InputDecoration(
                labelText: 'Nhập điểm từ 0 đến 10',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: checkGrade,
              child: const Text('Xếp loại'),
            ),
            const SizedBox(height: 20),
            Text(
              result,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const Divider(height: 32),
            const Text(
              'Ví dụ kiểm tra:\n'
              '9 → Giỏi\n'
              '7 → Khá\n'
              '5.5 → Trung bình\n'
              '3 → Yếu\n'
              '11 → Điểm không hợp lệ',
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}
